n = input("请输入整数N: ")
sum = 0
for i in range(int(n)):
    sum += i + 1
print("1 到N 求和结果: ", sum)
