PM = eval(input("请输入PM2.5 数值: "))
if PM >= 75:
    print("空气存在污染，请小心！")
else:
    print("空气没有污染，可以开展户外运动!")
