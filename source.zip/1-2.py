radius = 25 # 圆的半径是25
area = 3.1415 * radius * radius # 输入计算圆面积的公式
print(area)
print("{:.2f}".format(area)) # 只输出两位小数
