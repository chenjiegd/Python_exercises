name = input("输入姓名:")
print("%s 同学，学好Python，前途无量！"%name)
print("%s 大侠，学好Python，大展拳脚！"%name[0])
print("%s 哥哥，学好Python，人见人爱！"%name[1:])
