import turtle # 引用turtle 库
turtle.pensize(2) # 设置画笔宽度为2 像素
turtle.circle(10) # 绘制半径为10 像素的圆
turtle.circle(40) # 绘制半径为40 像素的圆
turtle.circle(80) # 绘制半径为80 像素的圆
turtle.circle(160) # 绘制半径为160 像素的圆
