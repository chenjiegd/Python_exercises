n = 1
for i in range(5,0,-1):
    n = (n+1)<<1
print(n)
